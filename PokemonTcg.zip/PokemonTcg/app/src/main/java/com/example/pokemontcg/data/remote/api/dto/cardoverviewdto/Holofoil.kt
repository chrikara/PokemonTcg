package com.example.pokemontcg.data.remote.api.dto.cardoverviewdto

data class Holofoil(
    val directLow: Double,
    val high: Double,
    val low: Double,
    val market: Double,
    val mid: Double
)