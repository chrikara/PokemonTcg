package com.example.pokemontcg.data.remote.api.dto.cardinfodto

data class Legalities(
    val unlimited: String
)