package com.example.pokemontcg.data.remote.api.dto.cardoverviewdto

data class ImagesX(
    val logo: String,
    val symbol: String
)