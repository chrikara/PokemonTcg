package com.example.pokemontcg.data.remote.api.dto.cardinfodto

data class Weaknesse(
    val type: String,
    val value: String
)