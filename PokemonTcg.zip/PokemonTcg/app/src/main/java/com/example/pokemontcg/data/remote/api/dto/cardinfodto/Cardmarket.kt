package com.example.pokemontcg.data.remote.api.dto.cardinfodto

data class Cardmarket(
    val prices: Prices,
    val updatedAt: String,
    val url: String
)