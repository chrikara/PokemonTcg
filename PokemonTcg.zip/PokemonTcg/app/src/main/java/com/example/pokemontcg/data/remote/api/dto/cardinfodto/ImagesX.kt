package com.example.pokemontcg.data.remote.api.dto.cardinfodto

data class ImagesX(
    val logo: String,
    val symbol: String
)