package com.example.pokemontcg.data.remote.api.dto.cardinfodto

data class Tcgplayer(
    val prices: PricesX,
    val updatedAt: String,
    val url: String
)