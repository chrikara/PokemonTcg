package com.example.pokemontcg.data.remote.api.dto.cardoverviewdto

data class Ability(
    val name: String,
    val text: String,
    val type: String
)