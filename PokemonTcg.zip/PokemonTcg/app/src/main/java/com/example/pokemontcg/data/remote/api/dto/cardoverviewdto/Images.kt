package com.example.pokemontcg.data.remote.api.dto.cardoverviewdto

data class Images(
    val large: String,
    val small: String
)