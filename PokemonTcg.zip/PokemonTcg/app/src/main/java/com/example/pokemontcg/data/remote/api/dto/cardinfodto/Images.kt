package com.example.pokemontcg.data.remote.api.dto.cardinfodto

data class Images(
    val large: String,
    val small: String
)