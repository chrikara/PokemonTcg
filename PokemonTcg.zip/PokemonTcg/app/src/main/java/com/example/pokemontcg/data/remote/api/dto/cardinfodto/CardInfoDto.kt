package com.example.pokemontcg.data.remote.api.dto.cardinfodto

data class CardInfoDto(
    val `data`: Data
)