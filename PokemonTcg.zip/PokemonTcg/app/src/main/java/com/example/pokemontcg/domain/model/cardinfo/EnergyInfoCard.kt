package com.example.pokemontcg.domain.model.cardinfo

data class EnergyInfoCard(
    val name : String = "",
    val imageUrl : String = "",
)
