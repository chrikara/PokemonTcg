package com.example.pokemontcg.data.remote.api.dto.cardoverviewdto

data class Weaknesse(
    val type: String,
    val value: String
)