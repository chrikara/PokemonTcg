package com.example.pokemontcg.data.remote.api.dto.cardoverviewdto

data class PricesX(
    val holofoil: Holofoil
)