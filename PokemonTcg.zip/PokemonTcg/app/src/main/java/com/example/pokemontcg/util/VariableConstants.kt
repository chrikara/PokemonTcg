package com.example.pokemontcg.util


val TOTAL_DECK_CARDS_GLOBAL = 40