package com.example.pokemontcg.util

object DangerousConstants {

    const val BASE_URL = "https://api.pokemontcg.io/"
    const val API_KEY = "42b02043-ebd7-474d-9e53-c8fa3e04019c"



}