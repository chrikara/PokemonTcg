package com.example.pokemontcg.data.remote.api.dto.cardinfodto

data class Resistances(
    val type: String,
    val value: String
)
